DROP TABLE `#__djimageslider`;
